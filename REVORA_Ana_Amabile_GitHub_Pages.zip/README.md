# Proposta Comercial REVORA — Ana Amábile

Apresentação comercial interativa criada em HTML5, CSS3 e JavaScript. Responsiva para celular e computador.

## Publicar usando GitHub Pages

1. Abra este repositório e confirme que `index.html` está na raiz da branch `main`.
2. Entre em **Settings → Pages**.
3. Em **Build and deployment**, selecione **Deploy from a branch**.
4. Escolha **main**, pasta **/(root)** e clique em **Save**.
5. Depois que a publicação terminar, acesse `https://<usuario>.github.io/<repositorio>/`.

> GitHub Pages publica este material na web. Qualquer pessoa com o endereço pode ver a proposta e os valores apresentados.

**Observação:** valores de investimento, implantação e escopo são preliminares e devem ser validados antes da aprovação comercial.
